# tariff - changes 

Changes in version 1.0.6 (2018-11-13)
=====================================
* clean out some duplicated codes for better readability


Changes in version 1.0.5 (2018-10-23)
=====================================
* Major update: Tariffs was calculated as counts of symptoms in previous versions. Now they are calculated as rates of symptoms.
* Add option to remove the default resampling step of training data for obtaining uniform cause distributions 

Changes in version 1.0.4 (2018-08-28)
=====================================
* Fix error in mismatching CSMF to cause names.
  
Changes in version 1.0.3 (2018-02-26)
======================================
* Fix error in extracting CSMF when use.rank set to TRUE.
  
